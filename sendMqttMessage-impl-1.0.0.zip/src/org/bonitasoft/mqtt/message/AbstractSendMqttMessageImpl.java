package org.bonitasoft.mqtt.message;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractSendMqttMessageImpl extends AbstractConnector {

	protected final static String BROKERURL_INPUT_PARAMETER = "brokerUrl";
	protected final static String CLIENTID_INPUT_PARAMETER = "clientId";
	protected final static String MESSAGETOPIC_INPUT_PARAMETER = "messageTopic";
	protected final static String MESSAGEQOS_INPUT_PARAMETER = "messageQos";
	protected final static String MESSAGECONTENT_INPUT_PARAMETER = "messageContent";

	protected final java.lang.String getBrokerUrl() {
		return (java.lang.String) getInputParameter(BROKERURL_INPUT_PARAMETER);
	}

	protected final java.lang.String getClientId() {
		return (java.lang.String) getInputParameter(CLIENTID_INPUT_PARAMETER);
	}

	protected final java.lang.String getMessageTopic() {
		return (java.lang.String) getInputParameter(MESSAGETOPIC_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getMessageQos() {
		return (java.lang.Integer) getInputParameter(MESSAGEQOS_INPUT_PARAMETER);
	}

	protected final java.lang.String getMessageContent() {
		return (java.lang.String) getInputParameter(MESSAGECONTENT_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getBrokerUrl();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("brokerUrl type is invalid");
		}
		try {
			getClientId();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("clientId type is invalid");
		}
		try {
			getMessageTopic();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"messageTopic type is invalid");
		}
		try {
			getMessageQos();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("messageQos type is invalid");
		}
		try {
			getMessageContent();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"messageContent type is invalid");
		}

	}

}
