/**
 * 
 */
package org.bonitasoft.mqtt.message;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.bonitasoft.engine.connector.ConnectorException;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;


/**
 * The connector execution will follow the steps 1 - setInputParameters() -->
 * the connector receives input parameters values 2 - validateInputParameters()
 * --> the connector can validate input parameters values 3 - connect() --> the
 * connector can establish a connection to a remote server (if necessary) 4 -
 * executeBusinessLogic() --> execute the connector 5 - getOutputParameters()
 * --> output are retrieved from connector 6 - disconnect() --> the connector
 * can close connection to remote server (if any)
 */
public class SendMqttMessageImpl extends AbstractSendMqttMessageImpl {

	private static Logger LOGGER = Logger.getLogger(SendMqttMessageImpl.class.getName());
	
	private MqttClient client;
	
	@Override
	protected void executeBusinessLogic() throws ConnectorException {
		// Prepare message
		MqttMessage message = new MqttMessage(getMessageContent().getBytes());
		if (getMessageQos() != null)
			message.setQos(getMessageQos().intValue());
		
		// Publish message
		if (LOGGER.isLoggable(Level.FINE))
			LOGGER.fine("Publishing message: " + getMessageContent());
		try {
			client.publish(getMessageTopic(), message);
		} catch (Exception e) {
			throw new ConnectorException("Failed to publish message: "+ e.getMessage(), e);
		}

		if (LOGGER.isLoggable(Level.FINE))
			LOGGER.fine("Message published");
	}

	@Override
	public void connect() throws ConnectorException {
		try {
			// Setup client and connection options
			client = new MqttClient(getBrokerUrl(), getClientId(), new MemoryPersistence());
			MqttConnectOptions options = new MqttConnectOptions();
			options.setCleanSession(true);
			
			// Connect
			if (LOGGER.isLoggable(Level.FINE))
				LOGGER.fine("Connecting to MQTT broker: " + getBrokerUrl());
			client.connect(options);
			if (LOGGER.isLoggable(Level.FINE))
				LOGGER.fine("Connected");
		} catch (MqttException e) {
			new ConnectorException("Failed to connect to MQTT: "+ e.getMessage(), e);
		}
	}

	@Override
	public void disconnect() throws ConnectorException {
		try {
			// Disconnect
			if (client != null && client.isConnected())
			{
				client.disconnect();
				if (LOGGER.isLoggable(Level.FINE))
					LOGGER.fine("Disconnected");
			}
		} catch (MqttException e) {
			new ConnectorException("Failed to disconnect from MQTT: "+ e.getMessage(), e);
		}
		
	}
}
